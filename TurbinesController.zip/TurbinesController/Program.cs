﻿using System;
using System.Collections.Generic;

namespace TurbinesController
{
    interface ITurbine
    {
        int turbineNumber { get; set; }
        string SendCommand(string cmd);
    }
    class CentralController
    {
        private readonly List<ITurbine> _turbines = new List<ITurbine>();

        public void AttachTurbine(ITurbine turbine)
        {
            if (!_turbines.Contains(turbine))
                _turbines.Add(turbine);
        }

        public string ShutdownTurbine(int turbineNumber)
        {
            var turbine = _turbines.Find(x => x.turbineNumber == turbineNumber);
            if (turbine == null)
                throw new Exception($" Turbine {turbineNumber} NOT Found!");

            _turbines.Remove(turbine);
            return $"Turbine {turbineNumber} is OFF";
        }

        public List<string> NotifyTurbine(string cmd)
        {
            var messages = new List<string>();

            foreach (ITurbine turbine in _turbines)
                messages.Add(turbine.SendCommand(cmd));

            return messages;
        }
    }

    class Turbine : ITurbine
    {
        public int turbineNumber { get; set; }
        public Turbine(int turbineNumber)
        {
            this.turbineNumber = turbineNumber;
        }

        public string SendCommand(string cmd)
        {
            return $"The turbine {turbineNumber} get command: {cmd}";
        }
    }

    class Program
    {
        static void Main()
        {
            var controller = new CentralController();

            // The Central Controller attached some turbines
            controller.AttachTurbine(new Turbine(turbineNumber: 1));
            controller.AttachTurbine(new Turbine(turbineNumber: 2));
            controller.AttachTurbine(new Turbine(turbineNumber: 3));
            controller.AttachTurbine(new Turbine(turbineNumber: 4));

            // All turbines are on operating
            var receivedMessages = controller.NotifyTurbine("[On Operation]");
            foreach(var msg in receivedMessages)
                Console.WriteLine(msg);


            // The central controller shuts down several turbines
            Console.WriteLine(controller.ShutdownTurbine(2));
            Console.WriteLine(controller.ShutdownTurbine(4));


            // After shutting down some turbines 
            receivedMessages = controller.NotifyTurbine("[On Operation]");
            foreach (var msg in receivedMessages)
                Console.WriteLine(msg);

            Console.ReadKey();
        }
    }
}
